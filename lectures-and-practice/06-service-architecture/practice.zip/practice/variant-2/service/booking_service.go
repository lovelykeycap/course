package service

import (
	"context"
	"github.com/course-go-autumn-2026/practice6-variant2-booking/domain"
)

type BookingService struct {
	repo         BookingRepository
	employees    EmployeeRepository
	availability RoomAvailability
	notifier     Notifier
}

func NewBookingService(repo BookingRepository, employees EmployeeRepository, availability RoomAvailability, notifier Notifier) *BookingService {
	return &BookingService{repo: repo, employees: employees, availability: availability, notifier: notifier}
}

type CreateInput struct {
	RoomID     int64
	EmployeeID int64
	StartAt    string
	EndAt      string
}

func (s *BookingService) Create(ctx context.Context, in CreateInput) (*domain.Booking, error) {
	startAt, endAt, err := domain.ParseInterval(in.StartAt, in.EndAt)
	if err != nil {
		return nil, err
	}
	employee := s.employees.Get(in.EmployeeID)
	overlapping := s.repo.FindOverlapping(in.RoomID, startAt, endAt)
	if overlapping != nil {
		if employee.Role != "admin" {
			return nil, domain.ErrAlreadyBooked
		}
		overlapping.Cancel()
	}

	roomAvailable, avErr := s.availability.Check(ctx, in.RoomID, in.StartAt, in.EndAt)
	// Fail-safe: при ошибке доступность не подтверждена, даже если порт вернул true.
	if avErr != nil {
		roomAvailable = false
	}
	booking, err := domain.NewBooking(in.RoomID, in.EmployeeID, startAt, endAt)
	if err != nil {
		return nil, err
	}
	s.repo.Create(booking)
	if roomAvailable {
		if err := booking.Confirm(); err != nil {
			return nil, err
		}
	}
	// Ошибка рассылки не влияет на создание и статус брони.
	_ = s.notifier.Send(ctx, booking.ID)
	return booking, nil
}

func (s *BookingService) Get(id int64) (*domain.Booking, error) {
	return s.repo.Get(id)
}

func (s *BookingService) UpdateTime(id int64, start, end string) (*domain.Booking, error) {
	newStart, newEnd, err := domain.ParseInterval(start, end)
	if err != nil {
		return nil, err
	}
	booking, err := s.repo.Get(id)
	if err != nil {
		return nil, err
	}
	if err := booking.Reschedule(newStart, newEnd); err != nil {
		return nil, err
	}
	return booking, nil
}
