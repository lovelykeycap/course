package service

import (
	"context"
	"github.com/course-go-autumn-2026/practice6-variant2-booking/domain"
	"time"
)

// BookingRepository — порт хранения бронирований.
// Get возвращает domain.ErrNotFound, если брони нет.
type BookingRepository interface {
	Get(id int64) (*domain.Booking, error)
	FindOverlapping(roomID int64, start, end time.Time) *domain.Booking
	Create(booking *domain.Booking) int64
}

type EmployeeRepository interface {
	Get(id int64) *domain.Employee
}

// RoomAvailability — порт проверки доступности комнаты.
// false означает, что доступность не подтверждена; ошибка — что проверка не удалась.
// Сервис в обоих случаях сохраняет pending_confirmation (fail-safe).
type RoomAvailability interface {
	Check(ctx context.Context, roomID int64, start, end string) (bool, error)
}

// Notifier — порт отправки уведомления после сохранения брони.
// Ошибка сообщает о неудачной отправке; сервис игнорирует её (fail-open).
// Вызов синхронный: контракт не обещает фоновую доставку.
type Notifier interface {
	Send(ctx context.Context, bookingID int64) error
}
