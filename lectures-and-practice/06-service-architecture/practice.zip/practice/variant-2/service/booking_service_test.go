package service_test

import (
	"context"
	"errors"
	"testing"

	"github.com/course-go-autumn-2026/practice6-variant2-booking/domain"
	"github.com/course-go-autumn-2026/practice6-variant2-booking/repository"
	"github.com/course-go-autumn-2026/practice6-variant2-booking/service"
)

type fakeAvailability struct {
	available bool
	err       error
}

func (f fakeAvailability) Check(context.Context, int64, string, string) (bool, error) {
	return f.available, f.err
}

type fakeNotifier struct {
	repo         service.BookingRepository
	err          error
	called       bool
	storedStatus domain.Status
}

func (f *fakeNotifier) Send(_ context.Context, id int64) error {
	f.called = true
	booking, err := f.repo.Get(id)
	if err != nil {
		return err
	}
	f.storedStatus = booking.Status()
	return f.err
}

func TestCreate_DependencyFailures(t *testing.T) {
	unavailable := errors.New("service unavailable")
	tests := []struct {
		name            string
		available       bool
		availabilityErr error
		want            domain.Status
	}{
		{"available", true, nil, domain.StatusConfirmed},
		{"unavailable", false, nil, domain.StatusPendingConfirmation},
		{"availability failure", false, unavailable, domain.StatusPendingConfirmation},
		{"availability failure overrides result", true, unavailable, domain.StatusPendingConfirmation},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			for _, notifyFails := range []bool{false, true} {
				repo := repository.NewMemoryBookingRepository()
				notifier := &fakeNotifier{repo: repo}
				if notifyFails {
					notifier.err = unavailable
				}
				svc := service.NewBookingService(repo, repository.NewMemoryEmployeeRepository(),
					fakeAvailability{available: tt.available, err: tt.availabilityErr}, notifier)
				booking, err := svc.Create(context.Background(), service.CreateInput{
					RoomID: 1, EmployeeID: 1,
					StartAt: "2026-11-01T10:00:00Z", EndAt: "2026-11-01T11:00:00Z",
				})
				if err != nil {
					t.Fatalf("notifyFails=%v: unexpected error: %v", notifyFails, err)
				}
				if booking.Status() != tt.want {
					t.Errorf("got %s, want %s", booking.Status(), tt.want)
				}
				if !notifier.called || notifier.storedStatus != tt.want {
					t.Errorf("notification must follow persistence with status %s; called=%v, storedStatus=%s", tt.want, notifier.called, notifier.storedStatus)
				}
				stored, err := svc.Get(booking.ID)
				if err != nil || stored.Status() != tt.want {
					t.Errorf("booking must remain saved; err=%v", err)
				}
			}
		})
	}
}
