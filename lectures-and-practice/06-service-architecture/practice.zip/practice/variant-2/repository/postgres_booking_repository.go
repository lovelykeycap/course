package repository

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"github.com/course-go-autumn-2026/practice6-variant2-booking/domain"
)

// findByID — учебный SQL-пример, не подключённый к хранилищу в памяти.
// Ошибка отсутствия строки переводится в доменную на границе адаптера.
func findByID(ctx context.Context, conn *sql.DB, id int64) (*domain.Booking, error) {
	row := conn.QueryRowContext(ctx, `SELECT * FROM bookings WHERE id = $1`, id)
	var b domain.BookingState
	err := row.Scan(&b.ID, &b.RoomID, &b.EmployeeID, &b.StartAt, &b.EndAt, &b.Status, &b.CreatedAt)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, domain.ErrNotFound
	}
	if err != nil {
		return nil, fmt.Errorf("find booking %d: %w", id, err)
	}
	booking, err := domain.RestoreBooking(b)
	if err != nil {
		// Невалидная запись — внутренняя ошибка хранения, а не ошибка запроса клиента.
		return nil, fmt.Errorf("restore booking %d: %v", id, err)
	}
	return booking, nil
}
