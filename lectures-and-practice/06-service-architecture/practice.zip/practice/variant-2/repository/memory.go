package repository

import (
	"github.com/course-go-autumn-2026/practice6-variant2-booking/domain"
	"github.com/course-go-autumn-2026/practice6-variant2-booking/service"
	"time"
)

var _ service.BookingRepository = (*MemoryBookingRepository)(nil)
var _ service.EmployeeRepository = (*MemoryEmployeeRepository)(nil)

type MemoryBookingRepository struct {
	db     map[int64]*domain.Booking
	nextID int64
}

func NewMemoryBookingRepository() *MemoryBookingRepository {
	return &MemoryBookingRepository{db: map[int64]*domain.Booking{}}
}

func (r *MemoryBookingRepository) Get(id int64) (*domain.Booking, error) {
	booking, ok := r.db[id]
	if !ok {
		return nil, domain.ErrNotFound
	}
	return booking, nil
}

func (r *MemoryBookingRepository) FindOverlapping(roomID int64, start, end time.Time) *domain.Booking {
	for _, b := range r.db {
		if b.Overlaps(roomID, start, end) {
			return b
		}
	}
	return nil
}

func (r *MemoryBookingRepository) Create(booking *domain.Booking) int64 {
	r.nextID++
	booking.ID = r.nextID
	r.db[booking.ID] = booking
	return booking.ID
}

type MemoryEmployeeRepository struct {
	employees map[int64]*domain.Employee
}

func NewMemoryEmployeeRepository() *MemoryEmployeeRepository {
	return &MemoryEmployeeRepository{employees: map[int64]*domain.Employee{
		1: {ID: 1, Role: "regular"},
		2: {ID: 2, Role: "admin"},
	}}
}

func (r *MemoryEmployeeRepository) Get(id int64) *domain.Employee {
	employee, ok := r.employees[id]
	if !ok {
		return &domain.Employee{ID: id, Role: "regular"}
	}
	return employee
}
