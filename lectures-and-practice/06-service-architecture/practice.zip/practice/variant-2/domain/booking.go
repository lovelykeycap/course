package domain

import (
	"encoding/json"
	"time"
)

type Status string

const (
	StatusPendingConfirmation Status = "pending_confirmation"
	StatusConfirmed           Status = "confirmed"
	StatusCancelled           Status = "cancelled"
	StatusRescheduling        Status = "rescheduling"
	rescheduleConfirmWindow          = 2 * time.Hour
)

// Booking хранит время и статус в закрытых полях: менять их можно только методами модели.
type Booking struct {
	ID         int64
	RoomID     int64
	EmployeeID int64
	CreatedAt  time.Time
	startAt    time.Time
	endAt      time.Time
	status     Status
}

func NewBooking(roomID, employeeID int64, startAt, endAt time.Time) (*Booking, error) {
	if !endAt.After(startAt) {
		return nil, ErrInvalidInterval
	}
	return &Booking{
		RoomID: roomID, EmployeeID: employeeID,
		startAt: startAt, endAt: endAt,
		status: StatusPendingConfirmation, CreatedAt: time.Now(),
	}, nil
}

func (b *Booking) StartAt() time.Time { return b.startAt }
func (b *Booking) EndAt() time.Time   { return b.endAt }
func (b *Booking) Status() Status     { return b.status }

func (b *Booking) Confirm() error {
	if b.status != StatusPendingConfirmation {
		return ErrInvalidStatusTransition
	}
	b.status = StatusConfirmed
	return nil
}

func (b *Booking) Cancel() {
	b.status = StatusCancelled
}

func (b *Booking) Reschedule(startAt, endAt time.Time) error {
	if !endAt.After(startAt) {
		return ErrInvalidInterval
	}
	if b.status == StatusCancelled {
		return ErrCancelled
	}
	b.startAt = startAt
	b.endAt = endAt
	if b.status == StatusConfirmed && time.Until(startAt) < rescheduleConfirmWindow {
		b.status = StatusRescheduling
	}
	return nil
}

func (b *Booking) Overlaps(roomID int64, startAt, endAt time.Time) bool {
	return b.RoomID == roomID && b.status != StatusCancelled &&
		startAt.Before(b.endAt) && b.startAt.Before(endAt)
}

// BookingState — представление для хранения и прежнего формата JSON.
type BookingState struct {
	ID         int64
	RoomID     int64
	EmployeeID int64
	StartAt    time.Time
	EndAt      time.Time
	Status     Status
	CreatedAt  time.Time
}

func RestoreBooking(state BookingState) (*Booking, error) {
	if !state.EndAt.After(state.StartAt) {
		return nil, ErrInvalidInterval
	}
	switch state.Status {
	case StatusPendingConfirmation, StatusConfirmed, StatusCancelled, StatusRescheduling:
	default:
		return nil, ErrInvalidStatusTransition
	}
	return &Booking{
		ID: state.ID, RoomID: state.RoomID, EmployeeID: state.EmployeeID,
		startAt: state.StartAt, endAt: state.EndAt, status: state.Status, CreatedAt: state.CreatedAt,
	}, nil
}

func (b *Booking) MarshalJSON() ([]byte, error) {
	return json.Marshal(BookingState{
		ID: b.ID, RoomID: b.RoomID, EmployeeID: b.EmployeeID,
		StartAt: b.startAt, EndAt: b.endAt, Status: b.status, CreatedAt: b.CreatedAt,
	})
}

type Employee struct {
	ID   int64
	Role string
}
