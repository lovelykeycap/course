package handler

import (
	"errors"
	"fmt"
	"net/http/httptest"
	"testing"

	"github.com/course-go-autumn-2026/practice6-variant2-booking/domain"
)

func TestWriteError(t *testing.T) {
	tests := []struct {
		name   string
		err    error
		status int
		body   string
	}{
		{"not found", domain.ErrNotFound, 404, ""},
		{"invalid start", domain.ErrInvalidStart, 400, "start_at must be a valid timestamp\n"},
		{"invalid end", domain.ErrInvalidEnd, 400, "end_at must be a valid timestamp\n"},
		{"invalid interval", domain.ErrInvalidInterval, 400, "end_at must be after start_at\n"},
		{"overlap", domain.ErrAlreadyBooked, 409, "room is already booked for this time\n"},
		{"cancelled", domain.ErrCancelled, 409, "cannot reschedule cancelled booking\n"},
		{"invalid transition", domain.ErrInvalidStatusTransition, 500, "internal error\n"},
		{"internal", errors.New("database credentials: secret"), 500, "internal error\n"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			for _, wrapped := range []bool{false, true} {
				err := tt.err
				if wrapped {
					err = fmt.Errorf("internal operation details: %w", err)
				}
				w := httptest.NewRecorder()
				writeError(w, err)
				if w.Code != tt.status || w.Body.String() != tt.body {
					t.Errorf("wrapped=%v: got (%d, %q), want (%d, %q)", wrapped, w.Code, w.Body.String(), tt.status, tt.body)
				}
			}
		})
	}
}
