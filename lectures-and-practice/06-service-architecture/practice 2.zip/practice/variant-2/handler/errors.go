package handler

import (
	"errors"
	"net/http"

	"github.com/course-go-autumn-2026/practice6-variant2-booking/domain"
)

func writeError(w http.ResponseWriter, err error) {
	if errors.Is(err, domain.ErrNotFound) {
		w.WriteHeader(http.StatusNotFound)
		return
	}
	for _, target := range []error{domain.ErrInvalidStart, domain.ErrInvalidEnd, domain.ErrInvalidInterval} {
		if errors.Is(err, target) {
			http.Error(w, target.Error(), http.StatusBadRequest)
			return
		}
	}
	for _, target := range []error{domain.ErrAlreadyBooked, domain.ErrCancelled} {
		if errors.Is(err, target) {
			http.Error(w, target.Error(), http.StatusConflict)
			return
		}
	}
	http.Error(w, "internal error", http.StatusInternalServerError)
}
